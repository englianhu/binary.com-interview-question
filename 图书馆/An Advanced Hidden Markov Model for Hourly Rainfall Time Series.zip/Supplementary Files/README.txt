An Advanced Hidden Markov Model for Hourly
Rainfall Time Series

Supplementary Files

This folder contains all of the code
and data necessary to reproduce the results
in the article. 

Please make sure your packages are up to date.

Contents:

- Data.RData 

R workspace containing the rainfall gauge observations,
as an object 'r'.

- Master.R

R script from which all the plots are generated.

- Functions.R

R script containing some functions needed to reproduce
results.

------------------------

Additional plots mentioned in the article can be found
in the Plots folder.
