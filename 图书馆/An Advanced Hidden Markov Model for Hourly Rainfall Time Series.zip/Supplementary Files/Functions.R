deregisterDistributions('drain')

aux=nimbleFunction(run=function(x=double(2),alpha=double(1),p=double(1),q=double(1),D=double(0),Z=double(0)){
  y=numeric(Z)
  for(j in 1:D){
    y[j]=sum(alpha*x[,j])
  }
  for(j in (D+1):Z){
    y[j]=sum(alpha* c((1-p)*q[j-D],x[(D+1):Z,j])  )
  }
  returnType(double(1))
  return(y)
})

forAlg2D=nimbleFunction(run=function(p_init=double(1),P_inhomo=double(2),P_static=double(2),n=double(0),Z=double(0),dens=double(2)){
  c=numeric(n)
  c[1]=sum(dens[1,]*p_init)
  alpha=(dens[1,]*p_init)/c[1]
  D=dim(P_inhomo)[2]
  P=P_static
  for(t in 2:n){
    P[1:D,1:D] <- diag(P_inhomo[t-1,])
    delta=dens[t,]*aux(P,alpha,P_inhomo[t-1,],P_static[1,(D+1):Z],D,Z)
    c[t]=sum(delta)
    alpha=delta/c[t]
  }
  returnType(double(0))
  return(sum(log(c)))
})

pow_vec <- nimbleFunction(run=function(x=double(1),y=double(1)){
  returnType(double(1))
  return(exp(y*log(x)))
})

pgpd <- nimbleFunction(run=function(x=double(1),threshold=double(1),scale=double(1),shape=double(1)){
  returnType(double(1))
  return(1-pow_vec(1+shape*(x-threshold)/scale,-1/shape))
})

pgpd_scalar <- nimbleFunction(run=function(x=double(0),threshold=double(0),scale=double(0),shape=double(0)){
  returnType(double(0))
  return(1-pow(1+shape*(x-threshold)/scale,-1/shape))
})

#test <- compileNimble(pgpd)
#test(c(10,11),c(0,1),c(2,3),c(1,2))

dzigpd <- nimbleFunction(run=function(x=double(1),p=double(1),scale=double(1),shape=double(1),log=integer(0)){
  returnType(double(1))
  n <- length(x)
  y <- p
  imis=x<0
  i1=x>0
  y[imis]=1
  y[i1] <- (1-p[i1])*( pow_vec(1+shape[i1]*(x[i1]-0.1)/scale[i1],-1/shape[i1])-pow_vec(1+shape[i1]*(x[i1]+0.1)/scale[i1],-1/shape[i1]))/pow_vec(1+shape[i1]*0.1/scale[i1],-1/shape[i1])
  return(y)
})

#dzigpd(c(1,2),c(0.5,0.6),c(2,3),c(0.25,0.5),log=1)
#test <- compileNimble(dzigpd)
#test(c(1,2),c(0.5,0.6),c(2,3),c(0.25,0.5),log=1)

rzigpd <- nimbleFunction(run=function(n=integer(0),p=double(0),scale=double(0),shape=double(0)){
  returnType(double(0))
  y=rbinom(1,1,1-p)
  if(y==0){
    return(0)
  }else{
    U=runif(1,pgpd_scalar(0.1,0,scale,shape),1)
    if(is.na(U)){
      U=1
    }
    if(1-U<1e-8){
      return(0.2)
    }else{
      y=((1-U)^(-shape)-1)/shape
      return(round((y*scale)*5)/5)
    }
  }
})

deregisterDistributions('drain')
drain <- nimbleFunction(
  run = function(x=double(1),P_zero=double(1),P_inhomo=double(2),P_static=double(2),N=double(0),Z=double(0),p=double(2),scale=double(2),shape=double(2),log = integer(0)) {
    dens=matrix(nrow=N,ncol=Z)
    for(j in 1:Z){
      dens[,j]=dzigpd(x,p[,j],scale[,j],shape[,j],log=FALSE)
    }
    returnType(double(0))
    return(forAlg2D(P_zero,P_inhomo,P_static,N,Z,dens))
  }
)

#drain <- nimbleFunction(
#  run = function(x=double(1),P_zero=double(1),P_inhomo=double(2),P_static=double(2),N=double(0),Z=double(0),D=double(0),W=double(0),X=double(2),beta=double(3),eta=double(1),alpha=double(1),gamma=double(1),log = integer(0)) {
#    
#    p <- matrix(nrow=N,ncol=Z)
#    scale <- matrix(nrow=N,ncol=Z)
#    shape <- matrix(nrow=N,ncol=Z)
#    for(j in 1:D){ # Conditional models for dry states.
#      p[,j] <- ilogit(rep(eta[1],N)+X%*%beta[,1,1]) 
#      scale[,j] <- exp(rep(alpha[1],N)+X%*%beta[,2,1]) 
#      shape[,j] <- rep(gamma[1],N)+X%*%beta[,3,1] 
#    } # Conditional models for wet states.
#    for(j in (D+1):(D+W)){
#      p[,j] <- ilogit(rep(eta[j-(D-1)],N)+X%*%beta[,1,j-(D-1)]) 
#      scale[,j] <- exp(rep(alpha[j-(D-1)],N)+X%*%beta[,2,j-(D-1)]) 
#      shape[,j] <- rep(gamma[j-(D-1)],N)+X%*%beta[,3,j-(D-1)] 
#    }
#    
#    dens=matrix(nrow=N,ncol=Z)
#    for(t in 1:N){
#      for(j in 1:Z){
#        dens[t,j]=dzigpd(x[t],p[t,j],scale[t,j],shape[t,j],log=FALSE) # Consider vectorising.
#      }
#    }
#    returnType(double(0))
#    return(forAlg2D(P_zero,P_inhomo,P_static,N,Z,dens))
#  }
#)


rrain <- nimbleFunction(
  run = function(n=integer(0),P_zero=double(1),P_inhomo=double(2),P_static=double(2),N=double(0),Z=double(0),p=double(2),scale=double(2),shape=double(2)) {
    y=numeric(N)
    z=numeric(N)
    z[1]=rcat(1,P_zero)
    D=dim(P_inhomo)[2]
    for(t in 2:N){
      P=P_static
      P[1:D,1:D] <- diag(P_inhomo[t-1,])
      P[1:D,(D+1):Z] <- (rep(1,D)-P_inhomo[t-1,])%*%t(P_static[1,(D+1):Z])
      z[t]=rcat(1,P[z[t-1],])
    }
    for(t in 1:N){
      y[t]=rzigpd(1,p[t,z[t]],scale[t,z[t]],shape[t,z[t]])
    }
    returnType(double(1))
    return(y)
  }
)


