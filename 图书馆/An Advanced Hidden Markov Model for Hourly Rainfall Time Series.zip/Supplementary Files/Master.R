# The following packages will need to be installed/updated.
library(nimble)
library(coda)
library(tidyverse)
library(gridExtra)
library(doParallel)
library(mgcv)
library(reshape2)
library(viridis)
library(ggfan)
library(devtools)
devtools::install_github("zeehio/facetscales")
library(facetscales)
library(grid)
library(abind)

nimbleOptions(experimentalEnableDerivs = FALSE)
nimbleOptions(oldConjugacyChecking = FALSE)
nimbleOptions(useNewConfigureMCMC = TRUE)

# Load in the script containing various functions.
source('Functions.R')

# Colour palette for plotting.
vp=viridis_pal(begin=0,end=0.6)(6)

# Load in the gauge observations.
load('Data.RData')

seed=c(17274757,52365823,34576435,16797945) # Random number generator seeds.

years <- 2010:2017

# Compute the dry persistence lengths.
data_dry_rle=rle(r<=0.2)
data_dry_persistence=data_dry_rle$lengths[data_dry_rle$values==1]

# Plot the quantiles of rainfall intensity and dry persistence lengths.

y=data_dry_persistence[!is.na(data_dry_persistence)]-1
p=1/(1+mean(y)) # Geometric method of moments estimate.

amount=ggplot(data_frame(x=seq(0,1,by=0.001),y=quantile(r[r>0],seq(0,1,by=0.001),na.rm=T)),aes(x=x,y=y))+geom_line(col=vp[3])+
  geom_point(data=tibble(x=0.99,y=quantile(r[r>0],0.99,na.rm=T)),col=vp[3])+
  geom_text(data=tibble(x=0.89,y=quantile(r[r>0],0.99,na.rm=T)),aes(label=quantile(r[r>0],0.99,na.rm=T)),col="#22211d")+
  labs(x='Quantile',y='Milimetres',title='Rainfall Intensity')+
  theme(
    text = element_text(color = "#22211d",size=10),plot.title = element_text(size=12),
    plot.background = element_rect(fill = "#f5f5f2", color = NA),
    panel.background = element_rect(fill = "#f5f5f2", color = NA),
    legend.background = element_rect(fill = NA, color = NA),panel.grid.minor = element_blank())
persistence=ggplot(data_frame(x=seq(0,1,by=0.01),y=quantile(data_dry_persistence,seq(0,1,by=0.01),na.rm=T)),aes(x=x,y=y))+
  geom_line(aes(col='Empirical Quantiles'))+
  geom_point(data=tibble(x=0.99,y=quantile(data_dry_persistence,0.99,na.rm=T)),aes(x=x,y=y,col='Empirical Quantiles'))+
  geom_text(data=tibble(x=0.89,y=quantile(data_dry_persistence,0.99,na.rm=T)),aes(label=round(quantile(data_dry_persistence,0.99,na.rm=T))),col="#22211d")+
  geom_line(data=tibble(x=seq(0,0.99,by=0.01),y=qgeom(seq(0,0.99,by=0.01),p)+1),aes(x=x,y=y,col='Geometric Fit'),linetype=2)+
  geom_point(data=tibble(x=0.99,y=qgeom(0.99,p)+1),aes(x=x,y=y,col='Geometric Fit'))+
  labs(x='Quantile',y='Hours',title='Dry Period Lengths')+
  theme(
    text = element_text(color = "#22211d",size=10),
    plot.background = element_rect(fill = "#f5f5f2", color = NA),
    panel.background = element_rect(fill = "#f5f5f2", color = NA),
    legend.background = element_rect(fill = NA, color = NA),panel.grid.minor = element_blank(),
    legend.position = c(0.45,0.75),legend.key = element_blank(),plot.title=element_text(size=12),
    legend.text = element_text(size=10))+
  scale_color_viridis_d(name=NULL,begin=0.36,end=0.48)
data_quantiles <- arrangeGrob(amount,persistence,nrow=1)
ggsave(data_quantiles,file='Plots/data_quantiles.pdf',width=6,height=2.25)

r_obs <- r[!is.na(r)] # Remove missing values for some plots / checks.

# Return level plot for rainfall.
rl=ggplot(data.frame(x=1/(1 - (1:length(r_obs))/(length(r_obs) + 1)),y=sort(r_obs)))+
  geom_point(aes(x=x,y=y),col=vp[3])+
  labs(x='Return Period (hours)',y='Return Level (mm)',title='Rainfall Observations')+
  theme(
    text = element_text(color = "#22211d"),
    plot.background = element_rect(fill = "#f5f5f2", color = NA),
    panel.background = element_rect(fill = "#f5f5f2", color = NA),
    legend.background = element_rect(fill = NA, color = NA),panel.grid.minor = element_blank())+
  scale_x_continuous(breaks=c(1,10,100,1000,10000))+coord_trans(x='log')
ggsave(rl,file='Plots/rl.pdf',width=3.5,height=2.75)

#########
# Model #
#########

# Store the observations in a data frame:
# y is the year index
# t is the hour index
rain_df <- tibble(t=1:length(r),r=r,y=floor((0:(length(r)-1))/8766)+1) 

Y=8 # Number of years to model
N=Y*8766 # Number of time steps

r=tail(rain_df$r,N)

# Periodic time index (based on inspection of Exeter gauge data, which starts at midnight on January 1st).
rain_df$tp=rain_df$t-(rain_df$y-1)*8766
rain_df$h <- rain_df$t%%24
rain_df$h[rain_df$h==0]=24
rain_df$h <- rain_df$h-1

# Specify the number of knots.
K1=8 # Number of knots for time of day spline.
K2=6 # Number of knots for the seasonal spline.
K3=12 # 1 random effect for each month.
K4=Y # 1 random effect for each year.

# Set up the spline basis functions.
setup_jagam=jagam(r~s(h,k=K1,bs='cc')+s(tp,k=K2,bs='cc'),knots=list(h=seq(0,24,length=K1),tp=seq(0,8766,length=K2)),na.action = na.pass,
                  data=tail(rain_df,N),file='blank.jags')

D=3 # Number of clone dry states.
W=2 # Number of wet states.
# The code is partially soft-coded but some things (such as the label-switching contraint)
# need to be changed if D or W are changed.

rain_code=nimbleCode({ # Model code (quasi BUGS language).
  
  # Data likelihood.
  r[1:n] ~ drain(P_zero[1:(D+W)],P_var[1:(n-1),1:D],P_static[1:(D+W),1:(D+W)],n,D+W,pi[1:n,1:(D+W)],sigma[1:n,1:(D+W)],xi[1:n,1:(D+W)])
  
  P_zero[1:(D+W)] ~ ddirch(prior[1:(D+W)]) # Initial state probabilities.
  
  # Construct the parts of the transition matrix which are time invariant.
  
  # Conditional probability of transition into each wet state.
  q[1:W] ~ ddirch(q_prior[1:W])
  
  P_static[1,1:D] <- rep(0,D)
  P_static[1,(D+1):(D+W)] <- q[1:W]
  for(i in 2:D){
    P_static[i,1:(D+W)] <- rep(0,D+W)
  }
  
  # Probability of transition into any dry or each wet state.
  for(i in 1:W){
    w[i,1:(W+1)] ~ ddirch(w_prior[1:(W+1)]) 
  }
  
  # Conditional probability of transition into each dry state.
  v[1:D] ~ ddirch(v_prior[1:D]) 
  
  P_static[(D+1):(D+W),1:D] <- w[1:W,1]%*%t(v[1:D])
  P_static[(D+1):(D+W),(D+1):(D+W)] <- w[1:W,2:(W+1)]
  
  # Construct the time variant part of transition matrix.
  for(d in 1:D){
    P_var[1:(n-1),d] <- ilogit(iota[d]+X[1:(n-1),1:K]%*%kappa[1:K])
  }
  
  # Time of day dry persistence spline.
  Tau_1[1:K1,1:K1] <- S1[1:K1,1:K1] * upsilon[1] 
  kappa[1:K1] ~ dmnorm(zero[1:K1],Tau_1[1:K1,1:K1]) 
  
  # Time of year dry persistence spline.
  Tau_2[1:K2,1:K2] <- S2[1:K2,1:K2] * upsilon[2] 
  kappa[(K1+1):(K1+K2)] ~ dmnorm(zero[(K1+1):(K1+K2)],Tau_2[1:K2,1:K2]) 
  
  # Monthly dry persistence effect.
  Tau_3[1:K3,1:K3] <- S3[1:K3,1:K3] * upsilon[3] 
  kappa[(K1+K2+1):(K1+K2+K3)] ~ dmnorm(zero[(K1+K2+1):(K1+K2+K3)],Tau_3[1:K3,1:K3]) 
  
  # Annual dry persistence effect.
  Tau_4[1:K4,1:K4] <- S4[1:K4,1:K4] * upsilon[4] 
  kappa[(K1+K2+K3+1):K] ~ dmnorm(zero[(K1+K2+K3+1):K],Tau_4[1:K4,1:K4]) 
  
  # Smoothing parameter priors for dry persistence splines.
  for(i in 1:4){
    upsilon[i] ~ dinvgamma(0.5,0.25)
  }
  
  # Dry persistence intercepts.
  for(d in 1:D){
    iota[d] ~ dnorm(0,sd=10)
  }
  
  for(j in 1:2){ # Conditional model splines.
    for(i in 1:3){
      # Time of day spline.
      Omega_1[1:K1,1:K1,i,j] <- S1[1:K1,1:K1] * lambda[1,i,j] 
      beta[1:K1,i,j] ~ dmnorm(zero[1:K1],Omega_1[1:K1,1:K1,i,j]) 
      
      # Time of year spline.
      Omega_2[1:K2,1:K2,i,j] <- S2[1:K2,1:K2] * lambda[2,i,j] 
      beta[(K1+1):(K1+K2),i,j] ~ dmnorm(zero[(K1+1):(K1+K2)],Omega_2[1:K2,1:K2,i,j]) 
      
      # Monthly effect.
      Omega_3[1:K3,1:K3,i,j] <- S3[1:K3,1:K3] * lambda[3,i,j] 
      beta[(K1+K2+1):(K1+K2+K3),i,j] ~ dmnorm(zero[(K1+K2+1):(K1+K2+K3)],Omega_3[1:K3,1:K3,i,j])
      
      # Annual effect.
      Omega_4[1:K4,1:K4,i,j] <- S4[1:K4,1:K4] * lambda[4,i,j] 
      beta[(K1+K2+K3+1):K,i,j] ~ dmnorm(zero[(K1+K2+K3+1):K],Omega_4[1:K4,1:K4,i,j])
      
      # Smoothing parameter priors.
      for(k in 1:4){
        lambda[k,i,j] ~ dinvgamma(0.5,0.25)
      }
    }
  }
  
  for(j in 1:D){ # Conditional models for dry states.
    pi[1:n,j] <- ilogit(rep(eta[1],n)+X[1:n,1:K]%*%beta[1:K,1,1]) # Zero probability.
    sigma[1:n,j] <- exp(rep(alpha[1],n)) # Scale parameter.
    xi[1:n,j] <- rep(gamma[1],n) # Shape parameter.
  } # Conditional models for wet states.
  for(j in (D+1):(D+W)){
    pi[1:n,j] <- ilogit(rep(eta[j-(D-1)],n)) # Zero probability.
    sigma[1:n,j] <- exp(rep(alpha[j-(D-1)],n)+X[1:n,1:K]%*%beta[1:K,2,j-D]) # Scale parameter.
    xi[1:n,j] <- rep(gamma[j-(D-1)],n)+X[1:n,1:K]%*%beta[1:K,3,j-D] # Shape parameter.
  }
  
  # Intercept priors.
  for(j in 1:(W+1)){
    eta[j] ~ dnorm(0,sd=10)
    alpha[j] ~ dnorm(0,sd=10)
    gamma[j] ~ dnorm(0,sd=10)
  }

  # Label switching constraint. Change this if using a different D or W.
  constraint ~ dconstraint( iota[2] < iota[1] & iota[3] < iota[2] & eta[1] > max(eta[2:3]) & exp(alpha[3])*(2^gamma[3]-1)/gamma[3] > exp(alpha[2])*(2^gamma[2]-1)/gamma[2]  ) 
  
})

# Create an index for the monthly random effect using the number of days in each month.
months_hours <- c(0,744,678,744,720,744,720,744,744,720,744,720,744)%>%cumsum()
month_index <- numeric(N)
for(i in 1:12){
  month_index[which(tail(rain_df$tp,N)>months_hours[[i]]&tail(rain_df$tp,N)<=months_hours[[i+1]])] <- i
}

# Create a year index for the yearly random effect.
year_index=sort(rep(1:Y,8766))

# Create model matrices for the random effects (i.e. X=1 if the time index is in that month/year).
X_months=matrix(0,nrow=N,ncol=12)
X_years=matrix(0,nrow=N,ncol=Y)
for(i in 1:N){
  X_months[i,month_index[i]]=1
  X_years[i,year_index[i]]=1
}

# Set up the data lists for the model.
rain_constants <- list(n = N,K1=K1-2,K2=K2-2,K3=K3,K4=K4,K=K1+K2+K3+K4-4,D=D,W=W,q_prior=rep(1,W),prior=rep(1,D+W),w_prior=rep(1,W+1),v_prior=rep(1,D))
rain_data <- list(r=r,X=cbind(setup_jagam$jags.data$X[,-1],X_months,X_years),S1=setup_jagam$jags.data$S1,S2=setup_jagam$jags.data$S2,S3=diag(rain_constants$K3),
                  S4=diag(rain_constants$K4),zero=rep(0,rain_constants$K),
                  constraint=1)

rain_data$r[is.na(r)]=-1 # Trick to 'integrate out' missing values. 

# Generate initial values for each chain.
rain_inits_function=function(seed){ 
  set.seed(seed)
  return(list(eta=c(runif(1,3,5),runif(1,0,3),runif(1,-10,0)),P_zero=rdirch(1,rep(1,D+W)),alpha=sort(rnorm(3,-0.5,0.05)),
              iota=sort(rnorm(3,0,1),decreasing = TRUE),v=rdirch(1,rep(1,3)),q=rdirch(1,c(1,1)),
              w=rbind(rdirch(1,rep(1,3)),rdirch(1,rep(1,3))),gamma=sort(rnorm(3,0.1,0.01)),
              beta=array(rnorm(3*2*rain_constants$K,0,0.01),dim=c(rain_constants$K,3,2)),lambda=array(rinvgamma(4*3*2,0.5,0.25),dim=c(4,3,2)),
              kappa=rnorm(rain_constants$K,0,0.01),upsilon=rinvgamma(4,0.5,0.25))
  )
}

rain_inits=list(c1=rain_inits_function(seed[1]),
                c2=rain_inits_function(seed[2]),
                c3=rain_inits_function(seed[3]),
                c4=rain_inits_function(seed[4]))

# Build the model and MCMC (for each chain).
rain_model <- rain_mcmc_conf <- rain_mcmc <- rain_model_compiled <- rain_mcmc_compiled <- list()
for(i in 1:4){ 
  # Create the model object and compile it.
  rain_model[[i]] <- nimbleModel(rain_code, rain_constants,rain_data,rain_inits[[i]])
  rain_model_compiled[[i]] <- compileNimble(rain_model[[i]],resetFunctions = TRUE)
  # Configure the MCMC.
  rain_mcmc_conf[[i]] <- configureMCMC(rain_model[[i]],monitors=c('P_zero','q','v','w','iota','eta','alpha','gamma','beta','lambda','kappa','upsilon'),
                                       useConjugacy = FALSE,control=list(scale=0.1,adaptInterval=1000))
  # Replace samplers for smoothing parameters with random walks at the log scale.
  rain_mcmc_conf[[i]]$removeSamplers(c('lambda','upsilon'))
  sapply(rain_model[[i]]$expandNodeNames('lambda'),function(x){rain_mcmc_conf[[i]]$addSampler(x,'RW',control=list(adaptInterval=1000,log=TRUE,scale=0.1))})
  sapply(rain_model[[i]]$expandNodeNames('upsilon'),function(x){rain_mcmc_conf[[i]]$addSampler(x,'RW',control=list(adaptInterval=1000,log=TRUE,scale=0.1))})
  # Build the MCMC and compile it.
  rain_mcmc[[i]] <- buildMCMC(rain_mcmc_conf[[i]])
  rain_mcmc_compiled[[i]] <- compileNimble(rain_mcmc[[i]], project = rain_model[[i]],resetFunctions = TRUE)
}

# Test the MCMC. is working as expected.
system.time({
  samples <- runMCMC(rain_mcmc_compiled[[1]],inits=rain_inits[[1]],setSeed=seed[1],
                     nchains = 1, nburnin=0,niter = 10,samplesAsCodaMCMC = TRUE,
                     summary = FALSE, WAIC = FALSE, thin=1)
})
# Check the initial log joint posterior is not -Inf.
lapply(rain_model,function(x)x$calculate())

registerDoParallel(cores=4) # Check this is not higher than your number of CPU cores minus 1.

# Takes over 12 hours.
rain_samples <- mcmc.list(foreach(i=1:4)%dopar%{
  samples <- runMCMC(rain_mcmc_compiled[[i]],inits=rain_inits[[i]],setSeed=seed[i],
                     nchains = 1, nburnin=10000,niter = 20000,samplesAsCodaMCMC = TRUE,
                     summary = FALSE, WAIC = FALSE, thin=1)
  return(samples)
})

save(rain_samples,file='samples_20_01_19.RData')

# Check convergence of MCMC chains.
psrf <- tibble(psrf=as.numeric(gelman.diag(rain_samples,autoburnin=FALSE,multivariate = FALSE,transform = TRUE)$psrf[,1]))
psrf_hist <- ggplot(psrf)+
  geom_histogram(aes(x=psrf),breaks=seq(0,1.25,by=0.025),fill=vp[3],alpha=0.5)+
  labs(title='Potential Scale Reduction Factor',x=NULL,y='Count')+
  scale_x_continuous(limits=c(1,1.25))+
  theme(
    text = element_text(color = "#22211d"),
    plot.background = element_rect(fill = "#f5f5f2", color = NA),
    panel.background = element_rect(fill = "#f5f5f2", color = NA),
    legend.background = element_rect(fill = NA, color = NA),panel.grid.minor = element_blank(),
    legend.position = c(0.45,0.75),legend.key = element_blank())
ggsave(psrf_hist,file='Plots/psrf_hist.pdf',width=4.5,height=3)

# Mean and median of univariate PSRF. We want these to be <1.05.
median(psrf$psrf)
mean(psrf$psrf)

# Combine MCMC chains.
rain_mcmc <- do.call('rbind',rain_samples)
# Thin MCMC samples by 10 to save computation time/memory.
rain_mcmc <- rain_mcmc[10*(1:4000),]

n_sim <- dim(rain_mcmc)[1] # Number of MCMC samples.

# Compute the dry state probability splines.
rain_kappa_matrix <- as.matrix(select(data.frame(rain_mcmc),contains('kappa')))

# Time of day spline.
rain_day_persistence <- rain_kappa_matrix[,1:rain_constants$K1]%*%t(rain_data$X[24:48,1:rain_constants$K1])
rain_day_persistence_quantiles <- apply(rain_day_persistence,2,quantile,c(0.025,0.5,0.975)) 
rain_day_persistence_data <- rain_day_persistence_quantiles%>%melt(varnames=c('quantile','t'))%>%spread(quantile,value)%>%mutate(t=as.numeric(t-1))

# Time of year spline.
rain_seasonal_persistence <- rain_kappa_matrix[,(rain_constants$K1+1):(rain_constants$K1+rain_constants$K2)]%*%t(rain_data$X[1:8766,(rain_constants$K1+1):(rain_constants$K1+rain_constants$K2)])
rain_seasonal_persistence_quantiles <- apply(rain_seasonal_persistence,2,quantile,c(0.025,0.5,0.975)) 
rain_seasonal_persistence_data <- rain_seasonal_persistence_quantiles%>%melt(varnames=c('quantile','t'))%>%spread(quantile,value)%>%mutate(t=as.numeric(t))

# Time of year spline + monthly random effect.
rain_month_persistence <- rain_kappa_matrix[,(rain_constants$K1+1):(rain_constants$K1+rain_constants$K2+rain_constants$K3)]%*%t(rain_data$X[(365+(0:11)*730),(rain_constants$K1+1):(rain_constants$K1+rain_constants$K2+rain_constants$K3)])
rain_month_persistence_data <- rain_month_persistence%>%melt(varnames=c('sample','t'))%>%mutate(t=(365.25+(0:11)*730.5)[t])

# Year random effect.
rain_temporal_persistence <- rain_kappa_matrix[,(rain_constants$K1+rain_constants$K2+rain_constants$K3+1):rain_constants$K]
rain_temporal_persistence_data <- rain_temporal_persistence%>%melt(varnames=c('sample','t'))%>%
  mutate(t=years[t])

# Function for manual box plots.
calc_boxplot_stat <- function(x) {
  coef <- 1.5
  n <- sum(!is.na(x))
  # calculate quantiles
  stats <- quantile(x, probs = c(0.0, 0.25, 0.5, 0.75, 1.0))
  names(stats) <- c("ymin", "lower", "middle", "upper", "ymax")
  iqr <- diff(stats[c(2, 4)])
  # set whiskers
  outliers <- x < (stats[2] - coef * iqr) | x > (stats[4] + coef * iqr)
  if (any(outliers)) {
    stats[c(1, 5)] <- range(c(stats[2:4], x[!outliers]), na.rm = TRUE)
  }
  return(stats)
}

# Plot the dry state probability splines.
day_persistence_plot <- ggplot(rain_day_persistence_data)+
  geom_ribbon(alpha=0.5,fill=vp[2],aes(x=t,ymin=`2.5%`,ymax=`97.5%`))+
  geom_line(size=1,colour=vp[2],aes(x=t,y=`50%`))+
  labs(x=NULL,y=NULL)+
  theme(text = element_text(color = "#22211d",size=10),plot.background = element_rect(fill = "#f5f5f2", color = NA),
        panel.background = element_rect(fill = "#f5f5f2", color = NA),
        plot.title=element_text(size=12))+
  scale_x_continuous(breaks=seq(0,24,by=6),
                     labels=c('00:00','06:00','12:00','18:00','24:00'))

seasonal_persistence_plot <- ggplot(rain_seasonal_persistence_data)+
  geom_ribbon(alpha=0.5,fill=vp[2],aes(x=t,ymin=`2.5%`,ymax=`97.5%`))+
  geom_line(size=1,colour=vp[2],aes(x=t,y=`50%`))+
  stat_summary(data=rain_month_persistence_data,mapping=aes(x=t,y=value,group=t),fun.data = calc_boxplot_stat, geom="boxplot",fill=vp[2],colour=vp[2],alpha=0.5,width=547.875)+
  labs(x=NULL,y=NULL)+
  theme(text = element_text(color = "#22211d",size=10),plot.background = element_rect(fill = "#f5f5f2", color = NA),
        panel.background = element_rect(fill = "#f5f5f2", color = NA),
        plot.title=element_text(size=12))+
  scale_x_continuous(breaks=c(365.25+(0:5)*2*730.5),
                     labels=c('Jan','Mar','May','Jul','Sep','Nov'))

temporal_persistence_plot <- ggplot(rain_temporal_persistence_data,aes(x=t,y=value,group=t))+
  stat_summary(fun.data = calc_boxplot_stat, geom="boxplot",fill=vp[2],colour=vp[2],alpha=0.5,width=0.75)+
  labs(x=NULL,y=NULL)+
  theme(text = element_text(color = "#22211d",size=10),plot.background = element_rect(fill = "#f5f5f2", color = NA),
        panel.background = element_rect(fill = "#f5f5f2", color = NA),
        plot.title=element_text(size=12))+scale_x_continuous(breaks=seq(2010,2017,by=2))

persistence_plots <- grobTree(rectGrob(gp=gpar(fill="#f5f5f2",col="#f5f5f2")),
                        arrangeGrob(day_persistence_plot,seasonal_persistence_plot,temporal_persistence_plot,nrow=1,top=textGrob("Dry State Persistence Effects (a)", gp=gpar(fontsize=12, col="#22211d"),just='left',x=0.062)))
ggsave(persistence_plots,file='Plots/persistence_plots.pdf',width=6,height=1.75)

# Compute the conditional model splines.
rain_beta_array <- array(as.matrix(select(data.frame(rain_mcmc),contains('beta'))),dim=c(n_sim,rain_constants$K,3,3))

# Time of day splines.
rain_day_splines <- array(NA,dim=c(n_sim,25,3,3))
rain_day_splines[,,1,1] <- rain_beta_array[,1:rain_constants$K1,1,1]%*%t(rain_data$X[24:48,1:rain_constants$K1])
for(i in 2:3){
  for(j in 1:2){
    rain_day_splines[,,i,1+j] <- rain_beta_array[,1:rain_constants$K1,i,j]%*%t(rain_data$X[24:48,1:rain_constants$K1])
  }
}
rain_day_quantiles=apply(rain_day_splines,c(2,3,4),quantile,c(0.025,0.5,0.975),na.rm=T)

# Seasonal splines.
rain_seasonal_splines <- array(dim=c(n_sim,8766,3,3))
rain_seasonal_splines[,,1,1] <- rain_beta_array[,(rain_constants$K1+1):(rain_constants$K1+rain_constants$K2),1,1]%*%t(rain_data$X[1:8766,(rain_constants$K1+1):(rain_constants$K1+rain_constants$K2)])
for(i in 2:3){
  for(j in 1:2){
    rain_seasonal_splines[,,i,1+j] <- rain_beta_array[,(rain_constants$K1+1):(rain_constants$K1+rain_constants$K2),i,j]%*%t(rain_data$X[1:8766,(rain_constants$K1+1):(rain_constants$K1+rain_constants$K2)])
  }
}
rain_seasonal_quantiles=apply(rain_seasonal_splines,c(2,3,4),quantile,c(0.025,0.5,0.975),na.rm=T)

# Seasonal splines + monthly random effect.
rain_month_effect <- array(dim=c(n_sim,12,3,3))
rain_month_effect[,,1,1] <- rain_beta_array[,(rain_constants$K1+1):(rain_constants$K1+rain_constants$K2+rain_constants$K3),1,1]%*%
  t(rain_data$X[(365+(0:11)*730),(rain_constants$K1+1):(rain_constants$K1+rain_constants$K2+rain_constants$K3)])
for(i in 2:3){
  for(j in 1:2){
    rain_month_effect[,,i,1+j] <- rain_beta_array[,(rain_constants$K1+1):(rain_constants$K1+rain_constants$K2+rain_constants$K3),i,j]%*%
      t(rain_data$X[(365+(0:11)*730),(rain_constants$K1+1):(rain_constants$K1+rain_constants$K2+rain_constants$K3)])
  }
}

# Temporal splines.
rain_temporal_splines <- array(dim=c(n_sim,Y,3,3))
rain_temporal_splines[,,1,1] <- rain_beta_array[,(rain_constants$K1+rain_constants$K2+rain_constants$K3+1):rain_constants$K,1,1]
for(i in 2:3){
  for(j in 1:2){
    rain_temporal_splines[,,i,1+j] <- rain_beta_array[,(rain_constants$K1+rain_constants$K2+rain_constants$K3+1):rain_constants$K,i,j]
  }
}

rain_day_data <- rain_day_quantiles%>%melt()%>%spread(Var1,value)%>%
  mutate(state=factor(c('Dry State','Wet State','Wetter State'),levels=c('Dry State','Wet State','Wetter State'))[Var4],
         type=factor(c('Zero Probability (b)','Scale (c)','Shape (g)'),levels=c('Zero Probability (b)','Scale (c)','Shape (g)'))[Var3],
         Var2=Var2-1)

rain_seasonal_data <- rain_seasonal_quantiles%>%melt()%>%spread(Var1,value)%>%
  mutate(state=factor(c('Dry State','Wet State','Wetter State'),levels=c('Dry State','Wet State','Wetter State'))[Var4],
         type=factor(c('Zero Probability (b)','Scale (c)','Shape (g)'),levels=c('Zero Probability (b)','Scale (c)','Shape (g)'))[Var3])

rain_month_data <- rain_month_effect%>%melt()%>%
  mutate(state=factor(c('Dry State','Wet State','Wetter State'),levels=c('Dry State','Wet State','Wetter State'))[Var4],
         type=factor(c('Zero Probability (b)','Scale (c)','Shape (g)'),levels=c('Zero Probability (b)','Scale (c)','Shape (g)'))[Var3])

rain_temporal_data <- rain_temporal_splines%>%melt()%>%
  mutate(state=factor(c('Dry State','Wet State','Wetter State'),levels=c('Dry State','Wet State','Wetter State'))[Var4],
         type=factor(c('Zero Probability (b)','Scale (c)','Shape (g)'),levels=c('Zero Probability (b)','Scale (c)','Shape (g)'))[Var3],
         Var2=years[Var2])

# Plot the conditional model splines.
day_effects=ggplot(rain_day_data)+
  geom_ribbon(aes(fill=state,x=Var2,ymin=`2.5%`,ymax=`97.5%`),alpha=0.5)+
  geom_line(aes(colour=state,x=Var2,y=`50%`),size=1)+
  labs(x=NULL,y=NULL,title='Time of Day Effects')+
  facet_wrap(~type,scales = 'free_y',nrow=3)+
  theme(text = element_text(color = "#22211d",size=10),plot.background = element_rect(fill = "#f5f5f2", color = NA),
        panel.background = element_rect(fill = "#f5f5f2", color = NA),strip.text = element_text(hjust=0.01,color = "#22211d",size = 10),
        strip.background = element_blank(),plot.title = element_text(hjust=0.01,color = "#22211d",size = 12),
        legend.background = element_blank(),legend.position = c(0.8,0.75))+
  guides(fill=FALSE,colour=FALSE)+
  scale_color_viridis_d(begin=0.12,end=0.48,name=NULL,guide=guide_legend(label.position = 'left'))+scale_fill_viridis_d(begin=0.12,end=0.48,name=NULL)+
  scale_x_continuous(breaks=seq(0,24,by=6),
                     labels=c('00:00','06:00','12:00','18:00','24:00'))


seasonal_effects=ggplot(rain_seasonal_data)+
  geom_ribbon(aes(fill=state,x=Var2,ymin=`2.5%`,ymax=`97.5%`),alpha=0.5)+
  geom_line(aes(colour=state,x=Var2,y=`50%`),size=1)+
  stat_summary(data=rain_month_data,
               mapping=aes(x=(365.25+(0:11)*730.5)[Var2],y=value,group=interaction(Var2,state),fill=state,colour=state),
               fun.data = calc_boxplot_stat, geom="boxplot",alpha=0.5,width=547.875,position = position_dodge(width=730.5))+
  labs(x=NULL,y=NULL,title='Seasonal Effects')+
  facet_wrap(~type,scales = 'free_y',nrow=3)+
  theme(text = element_text(color = "#22211d",size=10),plot.background = element_rect(fill = "#f5f5f2", color = NA),
        panel.background = element_rect(fill = "#f5f5f2", color = NA),strip.text = element_text(hjust=0.01,color = "#f5f5f2",size = 10),
        strip.background = element_blank(),plot.title = element_text(hjust=0.01,color = "#22211d",size = 12),
        legend.background = element_blank(),legend.position = c(0.5,0.71),legend.key.size = unit(1,'lines'))+
  scale_color_viridis_d(begin=0.12,end=0.48,name=NULL,guide=guide_legend(nrow=2))+scale_fill_viridis_d(begin=0.12,end=0.48,name=NULL)+
  guides(fill=FALSE,colour=FALSE)+
  scale_x_continuous(breaks=c(365.25+(0:5)*2*730.5),
                     labels=c('Jan','Mar','May','Jul','Sep','Nov'))

temporal_effects=ggplot(rain_temporal_data,aes(x=Var2,y=value))+
  stat_summary(fun.data = calc_boxplot_stat,mapping=aes(fill=state,colour=state,group=interaction(Var2,state)),
               geom="boxplot",alpha=0.5,width=0.75,position = position_dodge(width=1))+
  labs(x=NULL,y=NULL,title='Temporal Effects')+
  facet_wrap(~type,scales = 'free_y',nrow=3)+
  theme(text = element_text(color = "#22211d",size=10),plot.background = element_rect(fill = "#f5f5f2", color = NA),
        panel.background = element_rect(fill = "#f5f5f2", color = NA),strip.text = element_text(hjust=0.01,color = "#f5f5f2",size = 10),
        strip.background = element_blank(),plot.title = element_text(hjust=0.01,color = "#22211d",size = 12),
        legend.background = element_blank(),legend.position = c(0.36,1.045),legend.key.size = unit(1,'lines'))+
  scale_color_viridis_d(begin=0.12,end=0.48,name=NULL,guide=guide_legend(label.position = 'right',nrow=2))+scale_fill_viridis_d(begin=0.12,end=0.48,name=NULL)


conditional_effects <- arrangeGrob(day_effects,seasonal_effects,temporal_effects,nrow=1)
ggsave(conditional_effects,file='Plots/conditional_effects.pdf',width=6,height=4.5)

registerDoParallel(cores=8) # Check this is not higher than your number of CPU cores minus 1.
 
# Simulate replicate rain time series.
rain_sim_list=foreach(i=1:4000)%dopar%{
  # Extract the posterior samples.
  rain_P_zero=as.matrix(select(as.data.frame(rain_mcmc),contains('P_zero')))[i,]
  rain_q=as.matrix(select(as.data.frame(rain_mcmc),contains('q')))[i,]
  rain_v=as.matrix(select(as.data.frame(rain_mcmc),contains('v')))[i,]
  rain_w=matrix(as.matrix(select(as.data.frame(rain_mcmc),contains('w')))[i,],nrow=W)
  rain_iota=as.matrix(select(as.data.frame(rain_mcmc),contains('iota')))[i,]
  rain_kappa=as.matrix(select(as.data.frame(rain_mcmc),contains('kappa')))[i,]
  rain_alpha=as.matrix(select(as.data.frame(rain_mcmc),contains('alpha')))[i,]
  rain_beta=array(as.matrix(select(as.data.frame(rain_mcmc),contains('beta')))[i,],dim=c(rain_constants$K,3,2))
  rain_eta=rain_mcmc[i,c('eta[1]','eta[2]','eta[3]')]
  rain_gamma=as.matrix(select(as.data.frame(rain_mcmc),contains('gamma')))[i,]
  
  # Construct the static part of the transition matrix.
  rain_P_static=matrix(nrow=D+W,ncol=D+W)
  rain_P_static[1,1:D] <- rep(0,D)
  rain_P_static[1,(D+1):(D+W)] <- rain_q[1:W]
  for(i in 2:D){
    rain_P_static[i,1:(D+W)] <- rep(0,D+W)
  }
  rain_P_static[(D+1):(D+W),1:D] <- rain_w[1:W,1]%*%t(rain_v[1:D])
  rain_P_static[(D+1):(D+W),(D+1):(D+W)] <- rain_w[1:W,2:(W+1)]
  
  # Construct the time-variant part of the transition matrix.
  rain_P_var <- matrix(nrow=N-1,ncol=D)
  for(d in 1:D){
    rain_P_var[,d] <- ilogit(rep(rain_iota[d],N-1)+rain_data$X[1:(N-1),]%*%rain_kappa[1:rain_constants$K])
  }
  
  
  rain_pi=rain_sigma=rain_xi=matrix(nrow=N,ncol=D+W)
  
  for(d in 1:D){ # Conditional model for dry state.
    rain_pi[,d] <- expit(rain_eta[1]+rain_data$X[1:N,]%*%rain_beta[1:rain_constants$K,1,1])
    rain_sigma[,d] <- exp(rain_alpha[1])
    rain_xi[,d] <- rain_gamma[1]
  }
  for(j in (D+1):(D+W)){ # Conditional model for wet states.
    rain_pi[,j] <- expit(rain_eta[j-(D-1)])
    rain_sigma[,j] <- exp(rain_alpha[j-(D-1)]+rain_data$X[1:N,]%*%rain_beta[1:rain_constants$K,2,j-D])
    rain_xi[,j] <- rain_gamma[j-(D-1)]+rain_data$X[1:N,]%*%rain_beta[1:rain_constants$K,3,j-D]
  }
  
  return(rrain(1,rain_P_zero,rain_P_var,rain_P_static,N,D+W,rain_pi,rain_sigma,rain_xi))
}
  
save(rain_sim_list,file='sim_list_20_01_19.RData.RData')

###########
# Results #
###########

# Approximate seasonal breakdown.
winter_index <- which(tail(rain_df$tp,N)%in%c(1:1422,8023:8766)&!is.na(r))
spring_index <- which(tail(rain_df$tp,N)%in%1423:3630&!is.na(r))
summer_index <- which(tail(rain_df$tp,N)%in%3631:5838&!is.na(r))
autumn_index <-   which(tail(rain_df$tp,N)%in%5839:8022&!is.na(r))

# Quantiles by season.

quantiles <- seq(0,1,by=0.001)

winter_quantiles = do.call("rbind", lapply(rain_sim_list,function(x){quantile(x[winter_index][x[winter_index]>0],quantiles)}))%>%
  apply(2,quantile,c(0.025,0.5,0.975))%>%melt(varnames=c('quantile','index'))%>%
  spread(quantile,value)%>%mutate(y=quantile(r[winter_index][r[winter_index]>0],quantiles))
spring_quantiles = do.call("rbind", lapply(rain_sim_list,function(x){quantile(x[spring_index][x[spring_index]>0],quantiles)}))%>%
  apply(2,quantile,c(0.025,0.5,0.975))%>%melt(varnames=c('quantile','index'))%>%
  spread(quantile,value)%>%mutate(y=quantile(r[spring_index][r[spring_index]>0],quantiles))
summer_quantiles = do.call("rbind", lapply(rain_sim_list,function(x){quantile(x[summer_index][x[summer_index]>0],quantiles)}))%>%
  apply(2,quantile,c(0.025,0.5,0.975))%>%melt(varnames=c('quantile','index'))%>%
  spread(quantile,value)%>%mutate(y=quantile(r[summer_index][r[summer_index]>0],quantiles))
autumn_quantiles = do.call("rbind", lapply(rain_sim_list,function(x){quantile(x[autumn_index][x[autumn_index]>0],quantiles)}))%>%
  apply(2,quantile,c(0.025,0.5,0.975))%>%melt(varnames=c('quantile','index'))%>%
  spread(quantile,value)%>%mutate(y=quantile(r[autumn_index][r[autumn_index]>0],quantiles))

season_quantiles <- rbind(mutate(winter_quantiles,season='Winter'),mutate(spring_quantiles,season='Spring'),
                       mutate(summer_quantiles,season='Summer'),mutate(autumn_quantiles,season='Autumn'))%>%
  mutate(season=factor(season,level=c('Winter','Spring','Summer','Autumn')))

# Season quantiles plots.
season_quantiles_plot <- ggplot(season_quantiles)+
  geom_abline(intercept=0,slope=1,col="#22211d")+
  geom_ribbon(aes(x=y,ymin=`2.5%`,ymax=`97.5%`,fill=season),alpha=0.5)+
  geom_point(aes(x=y,y=`50%`,colour=season),size=1)+xlab('Observed Rainfall Quantiles (mm)')+
  facet_wrap(~season,nrow=2,scales='free')+
  ylab('Simulated Rainfall Quantiles (mm)')+
  theme(text = element_text(color = "#22211d",size=10),plot.background = element_rect(fill = "#f5f5f2", color = NA),
        panel.background = element_rect(fill = "#f5f5f2", color = NA),strip.text = element_text(hjust=0,size = 12),
        strip.background = element_blank(),panel.grid.minor = element_blank())+
  scale_fill_manual(values=vp[2:5],guide=FALSE)+scale_colour_manual(values=vp[2:5],guide=FALSE)
ggsave(season_quantiles_plot,file='Plots/season_quantiles.pdf',width=6,height=4)

# Approximate 3-hourly quantiles by season.

agg_3h <- function(y){
  l <- floor(length(y)/3)
  return(y[3*(1:l)-2]+y[3*(1:l)-1]+y[3*(1:l)])
}

winter_quantiles_3h = do.call("rbind", lapply(rain_sim_list,function(x){quantile(agg_3h(x[winter_index][x[winter_index]>0]),quantiles)}))%>%
  apply(2,quantile,c(0.025,0.5,0.975))%>%melt(varnames=c('quantile','index'))%>%
  spread(quantile,value)%>%mutate(y=quantile(agg_3h(r[winter_index][r[winter_index]>0]),quantiles))
spring_quantiles_3h = do.call("rbind", lapply(rain_sim_list,function(x){quantile(agg_3h(x[spring_index][x[spring_index]>0]),quantiles)}))%>%
  apply(2,quantile,c(0.025,0.5,0.975))%>%melt(varnames=c('quantile','index'))%>%
  spread(quantile,value)%>%mutate(y=quantile(agg_3h(r[spring_index][r[spring_index]>0]),quantiles))
summer_quantiles_3h = do.call("rbind", lapply(rain_sim_list,function(x){quantile(agg_3h(x[summer_index][x[summer_index]>0]),quantiles)}))%>%
  apply(2,quantile,c(0.025,0.5,0.975))%>%melt(varnames=c('quantile','index'))%>%
  spread(quantile,value)%>%mutate(y=quantile(agg_3h(r[summer_index][r[summer_index]>0]),quantiles))
autumn_quantiles_3h = do.call("rbind", lapply(rain_sim_list,function(x){quantile(agg_3h(x[autumn_index][x[autumn_index]>0]),quantiles)}))%>%
  apply(2,quantile,c(0.025,0.5,0.975))%>%melt(varnames=c('quantile','index'))%>%
  spread(quantile,value)%>%mutate(y=quantile(agg_3h(r[autumn_index][r[autumn_index]>0]),quantiles))

season_quantiles_3h <- rbind(mutate(winter_quantiles_3h,season='Winter'),mutate(spring_quantiles_3h,season='Spring'),
                          mutate(summer_quantiles_3h,season='Summer'),mutate(autumn_quantiles_3h,season='Autumn'))%>%
  mutate(season=factor(season,level=c('Winter','Spring','Summer','Autumn')))

# Season quantiles plots.
season_quantiles_plot_3h <- ggplot(season_quantiles_3h)+
  geom_abline(intercept=0,slope=1,col="#22211d")+
  geom_ribbon(aes(x=y,ymin=`2.5%`,ymax=`97.5%`,fill=season),alpha=0.5)+
  geom_point(aes(x=y,y=`50%`,colour=season),size=1)+xlab('Observed 3-Hourly Rainfall Quantiles (mm)')+
  facet_wrap(~season,nrow=2,scales='free')+
  ylab('Simulated 3-Hourly Rainfall Quantiles (mm)')+
  theme(text = element_text(color = "#22211d",size=10),plot.background = element_rect(fill = "#f5f5f2", color = NA),
        panel.background = element_rect(fill = "#f5f5f2", color = NA),strip.text = element_text(hjust=0,size = 12),
        strip.background = element_blank(),panel.grid.minor = element_blank())+
  scale_fill_manual(values=vp[2:5],guide=FALSE)+scale_colour_manual(values=vp[2:5],guide=FALSE)
ggsave(season_quantiles_plot_3h,file='Plots/season_quantiles_3h.png',width=6,height=4)
ggsave(season_quantiles_plot_3h,file='Plots/season_quantiles_3h.pdf',width=6,height=4)


# Monthly quantiles plots.
months_sorted <- list()
months_hours <- c(0,744,678,744,720,744,720,744,744,720,744,720,744)%>%cumsum()
months_index <- list()
for(i in 1:12){
  months_index[[i]]=list()
  months_index[[i]][[1]]=i
  months_index[[i]][[2]]=which(tail(rain_df$tp,N)>months_hours[[i]]&tail(rain_df$tp,N)<=months_hours[[i+1]]&!is.na(r))
}
months_quantiles_list <- lapply(months_index,function(m){
  do.call("rbind",lapply(rain_sim_list,function(x){quantile(x[m[[2]]][x[m[[2]]]>0],quantiles[seq(1,1001,length=201)])}))%>%
    apply(2,quantile,c(0.025,0.5,0.975))%>%melt(varnames=c('quantile','index'))%>%
    spread(quantile,value)%>%mutate(month=m[[1]],data=quantile(r[m[[2]]][r[m[[2]]]>0],quantiles[seq(1,1001,length=201)]))
})
months_quantiles <- do.call('rbind', months_quantiles_list)
months_quantiles <- months_quantiles%>%mutate(month=factor(c('January','February','March','April','May','June','July','August','September','October','November','December'),
                                                           levels=c('January','February','March','April','May','June','July','August','September','October','November','December'))[month])

months_plot <- ggplot(months_quantiles)+
  geom_abline(intercept=0,slope=1,col="#22211d")+
  geom_ribbon(aes(x=data,ymin=`2.5%`,ymax=`97.5%`,fill=month),alpha=0.5)+
  geom_point(aes(x=data,y=`50%`,colour=month),size=1)+xlab('Observed Rainfall Quantiles (mm)')+
  facet_wrap(~month,nrow=3,scales='free')+
  ylab('Simulated Rainfall Quantiles (mm)')+
  theme(text = element_text(color = "#22211d",size=10),plot.background = element_rect(fill = "#f5f5f2", color = NA),
        panel.background = element_rect(fill = "#f5f5f2", color = NA),strip.text = element_text(hjust=0,size = 12),
        strip.background = element_blank(),panel.grid.minor = element_blank())+scale_fill_viridis_d(begin=0.12,end=0.48)+
  scale_colour_viridis_d(begin=0.12,end=0.48)+guides(fill=FALSE,colour=FALSE)

ggsave(months_plot,file='Plots/months.pdf',width=6,height=4)
ggsave(months_plot,file='Plots/months.png',width=6,height=4)

# Annual quantiles plots.

years=2010:2017
year_quantiles <- list()
for(i in 1:Y){
  year_index <- base::intersect((8766*(i-1)+1):(8766*i),which(!is.na(r)))
  year_quantiles[[i]]=do.call("rbind", lapply(rain_sim_list,function(x){quantile(x[year_index][x[year_index]>0],quantiles)}))%>%
    apply(2,quantile,c(0.025,0.5,0.975))%>%melt(varnames=c('quantile','index'))%>%
    spread(quantile,value)%>%mutate(y=quantile(r[year_index][r[year_index]>0],quantiles),year=years[i])
}

year_quantiles <- do.call('rbind',year_quantiles)

year_quantiles_plot <- ggplot(year_quantiles)+
  geom_abline(intercept=0,slope=1,col="#22211d")+
  geom_ribbon(aes(x=y,ymin=`2.5%`,ymax=`97.5%`,fill=year),alpha=0.5)+
  geom_point(aes(x=y,y=`50%`,colour=year),size=1)+xlab('Observed Rainfall Quantiles (mm)')+
  facet_wrap(~year,nrow=2,scales='free')+
  ylab('Simulated Rainfall Quantiles (mm)')+
  theme_minimal()+theme(text = element_text(color = "#22211d",size=10),plot.background = element_rect(fill = "#f5f5f2", color = NA),
                        panel.background = element_rect(fill = "#f5f5f2", color = NA),strip.text = element_text(hjust=0,size = 12),
                        strip.background = element_blank(),panel.grid.minor = element_blank())+scale_fill_viridis(begin=0.12,end=0.48)+
  scale_colour_viridis(begin=0.12,end=0.48)+guides(fill=FALSE,colour=FALSE)

ggsave(year_quantiles_plot,file='Plots/year_quantiles.pdf',width=6,height=3.5)
ggsave(year_quantiles_plot,file='Plots/year_quantiles.png',width=6,height=3.5)

# Season zero proportion plots.

winter_zero = unlist(lapply(rain_sim_list,function(x){mean(x[winter_index]==0)}))
spring_zero = unlist(lapply(rain_sim_list,function(x){mean(x[spring_index]==0)}))
summer_zero = unlist(lapply(rain_sim_list,function(x){mean(x[summer_index]==0)}))
autumn_zero = unlist(lapply(rain_sim_list,function(x){mean(x[autumn_index]==0)}))
season_zero <- tibble(x=c(winter_zero,summer_zero,spring_zero,autumn_zero),season=sort(rep(c(1:4),n_sim)))%>%
  mutate(season=factor(c('Winter','Spring','Summer','Autumn'),levels=c('Winter','Spring','Summer','Autumn'))[season])
true_zero <- tibble(x=c(mean(r[winter_index]==0),mean(r[spring_index]==0),mean(r[summer_index]==0),mean(r[autumn_index]==0)),
                    season=factor(c('Winter','Spring','Summer','Autumn'),levels=c('Winter','Spring','Summer','Autumn')))

scales_x <- list('Winter'=scale_x_continuous(breaks=c(0.82,0.84,0.86,0.88)),'Spring'=scale_x_continuous(breaks=c(0.88,0.9,0.92,0.94)),
                 'Summer'=scale_x_continuous(breaks=c(0.87,0.89,0.91,0.93)),'Autumn'=scale_x_continuous(breaks=c(0.85,0.87,0.89,0.91)))
season_zero_plot <- ggplot(season_zero)+
  stat_density(aes(x=x,fill=season),alpha=0.5,adjust=1.5)+
  facet_grid_sc(cols=vars(season),scales=list(x=scales_x))+
  labs(y='Density',title='Proportion of Hours with Zero Rainfall',x=NULL)+
  theme(text = element_text(color = "#22211d",size=15),plot.background = element_rect(fill = "#f5f5f2", color = NA),
        panel.background = element_rect(fill = "#f5f5f2", color = NA),strip.text = element_text(hjust=0.01,color = "#22211d",size = 15),
        strip.background = element_blank(),panel.grid.minor = element_blank(),plot.title = element_text(hjust=0.01,color = "#22211d",size = 18))+
  geom_vline(data=true_zero,aes(xintercept=x),col="#22211d")+
  scale_fill_viridis_d(begin=0.12,end=0.48,guide='none')
ggsave(season_zero_plot,file='Plots/season_zero.pdf',width=9,height=2.5)


# Check spearman auto-correlations (superceded by joint exceedence probability check).
rain_cor_1 = do.call("c", lapply(rain_sim_list,function(x){
  x <- x[!is.na(r)]
  cor(x[1:(length(x)-1)],x[2:length(x)],method='spearman')
}))
rain_cor_2 = do.call("c", lapply(rain_sim_list,function(x){
  x <- x[!is.na(r)]
  cor(x[1:(length(x)-2)],x[3:length(x)],method='spearman')
}))
rain_cor_6 = do.call("c", lapply(rain_sim_list,function(x){
  x <- x[!is.na(r)]
  cor(x[1:(length(x)-6)],x[7:length(x)],method='spearman')
}))
rain_cor_24 = do.call("c", lapply(rain_sim_list,function(x){
  x <- x[!is.na(r)]
  cor(x[1:(length(x)-24)],x[25:length(x)],method='spearman')
}))

cor_data <- tibble(cor=c(rain_cor_1,rain_cor_2,rain_cor_6,rain_cor_24),lag=sort(rep(c(1,2,3,4),n_sim)))%>%
  mutate(lag=factor(c('Lag 1','Lag 2','Lag 6','Lag 24'),levels=c('Lag 1','Lag 2','Lag 6','Lag 24'))[lag])
true_cor <- tibble(cor=c(cor(r_obs[1:(length(r_obs)-1)],r_obs[2:length(r_obs)],method='spearman'),
                         cor(r_obs[1:(length(r_obs)-2)],r_obs[3:length(r_obs)],method='spearman'),
                         cor(r_obs[1:(length(r_obs)-6)],r_obs[7:length(r_obs)],method='spearman'),
                         cor(r_obs[1:(length(r_obs)-24)],r_obs[25:length(r_obs)],method='spearman')),
                   lag=c(1,2,3,4))%>%
  mutate(lag=factor(c('Lag 1','Lag 2','Lag 6','Lag 24'),levels=c('Lag 1','Lag 2','Lag 6','Lag 24'))[lag])

autocor_plot <- ggplot(cor_data)+
  stat_density(aes(x=cor),fill=vp[3],alpha=0.5,adjust=1.5)+
  labs(y='Density',title='Spearman Auto-Correlation',x=NULL)+
  facet_wrap(~lag,scales='free',nrow=1)+
  geom_vline(data=true_cor,aes(xintercept=cor),col="#22211d")+
  theme(text = element_text(color = "#22211d",size=15),plot.background = element_rect(fill = "#f5f5f2", color = NA),
        panel.background = element_rect(fill = "#f5f5f2", color = NA),strip.text = element_text(hjust=0.01,color = "#22211d",size = 15),
        strip.background = element_blank(),panel.grid.minor = element_blank(),plot.title = element_text(hjust=0.01,color = "#22211d",size = 18))+
  scale_fill_viridis_d(begin=0.12,end=0.48,guide='none')
ggsave(autocor_plot,file='Plots/autocor_plot.pdf',width=9,height=2.5)

# Check dry and wet period persistence.

# Persistence of zero-rainfall periods.
data_dry_rle_0=rle(r<=0)
data_dry_persistence_0=data_dry_rle_0$lengths[data_dry_rle_0$values==1]

rain_dry_persistence_0 = do.call("rbind", lapply(rain_sim_list,function(x){
  x[is.na(r)]=NA
  dry_rle=rle(x<=0)
  dry_persistence=dry_rle$lengths[dry_rle$values==1]
  return(quantile(dry_persistence,quantiles[seq(1,1001,length=201)],na.rm=T))
}))

# Persistence of virtually-zero rainfall periods.
data_dry_rle_2=rle(r<=0.2)
data_dry_persistence_2=data_dry_rle_2$lengths[data_dry_rle_2$values==1]

rain_dry_persistence_2 = do.call("rbind", lapply(rain_sim_list,function(x){
  x[is.na(r)]=NA
  dry_rle=rle(x<=0.2)
  dry_persistence=dry_rle$lengths[dry_rle$values==1]
  return(quantile(dry_persistence,quantiles[seq(1,1001,length=201)],na.rm=T))
}))

# Persistence of non-zero rainfall periods.
rain_wet_persistence = do.call("rbind", lapply(rain_sim_list,function(x){
  x[is.na(r)]=NA
  wet_rle=rle(x>0)
  wet_persistence=wet_rle$lengths[wet_rle$values==1]
  return(quantile(wet_persistence,quantiles[seq(1,1001,length=201)],na.rm=T))
}))

data_wet_rle=rle(r>0)
data_wet_persistence=data_wet_rle$lengths[data_wet_rle$values==1]

persistence_factor <- factor(c('Zero Rainfall','Virtually Zero Rainfall','Non-Zero Rainfall'),
                             levels=c('Zero Rainfall','Virtually Zero Rainfall','Non-Zero Rainfall'))

rain_persistence <- abind(apply(rain_dry_persistence_0,2,quantile,c(0.025,0.5,0.975)),
                          apply(rain_dry_persistence_2,2,quantile,c(0.025,0.5,0.975)),
                          apply(rain_wet_persistence,2,quantile,c(0.025,0.5,0.975)),along=3)%>%
  melt(varnames=c('quantile','rank','type'),value.name='r')%>%spread(quantile,r)%>%
  mutate(type=persistence_factor[type])

rain_persistence$data=as.numeric(rbind(quantile(data_dry_persistence_0,quantiles[seq(1,1001,length=201)],na.rm=T),
                                       quantile(data_dry_persistence_2,quantiles[seq(1,1001,length=201)],na.rm=T),
                                       quantile(data_wet_persistence,quantiles[seq(1,1001,length=201)],na.rm=T)))

persistence_plot <- ggplot(rain_persistence)+
  geom_abline(intercept=0,slope=1,col="#22211d")+
  geom_ribbon(aes(x=data,ymin=`2.5%`,ymax=`97.5%`,fill=type),alpha=0.5)+geom_point(aes(x=data,y=`50%`,colour=type),size=1)+
  facet_wrap(~type,scales='free')+
  labs(title='Persistence of Dry and Wet Periods',x='Observed Quantiles (Hours)',y='Simulated Quantiles (Hours)')+
  theme(text = element_text(color = "#22211d",size=15),plot.background = element_rect(fill = "#f5f5f2", color = NA),
        panel.background = element_rect(fill = "#f5f5f2", color = NA),strip.text = element_text(hjust=0.01,color = "#22211d",size = 15),
        strip.background = element_blank(),panel.grid.minor = element_blank(),plot.title = element_text(hjust=0.01,color = "#22211d",size = 18))+
  #scale_x_continuous(trans='log10')+scale_y_continuous(trans='log10')+
  scale_color_viridis_d(begin=0.12,end=0.48,name=NULL)+scale_fill_viridis_d(begin=0.12,end=0.48,name=NULL)+guides(fill=FALSE,colour=FALSE)

ggsave(persistence_plot,file='Plots/persistence.pdf',width=9,height=3)


# Daily model checking

ND <- N/24
r_daily <- numeric(ND)
for(t in 1:ND){
  r_daily[t] <- sum(r[(t-1)*24+1:24])
}

daily_sim_list <- lapply(rain_sim_list,function(x){
  y <- numeric(ND)
  for(t in 1:ND){
    y[t] <- sum(x[(t-1)*24+1:24])
  }
  return(y)
})

daily_quantiles = do.call("rbind", lapply(daily_sim_list,function(x){quantile(x[!is.na(r_daily)][x[!is.na(r_daily)]>0],quantiles[seq(1,1001,length=101)])}))

# Check auto-correlations.
daily_cor_1 = do.call("c", lapply(daily_sim_list,function(x){
  x <- x[!is.na(r_daily)]
  cor(x[1:(length(x)-1)],x[2:length(x)],method='spearman')
}))
daily_cor_2 = do.call("c", lapply(daily_sim_list,function(x){
  x <- x[!is.na(r_daily)]
  cor(x[1:(length(x)-2)],x[3:length(x)],method='spearman')
}))
daily_cor_7 = do.call("c", lapply(daily_sim_list,function(x){
  x <- x[!is.na(r_daily)]
  cor(x[1:(length(x)-7)],x[8:length(x)],method='spearman')
}))
daily_cor_14 = do.call("c", lapply(daily_sim_list,function(x){
  x <- x[!is.na(r_daily)]
  cor(x[1:(length(x)-14)],x[15:length(x)],method='spearman')
}))

r_daily_obs <- r_daily[!is.na(r_daily)]

daily_cor_data <- tibble(cor=c(daily_cor_1,daily_cor_2,daily_cor_7,daily_cor_14),lag=sort(rep(c(1,2,3,4),n_sim)))%>%
  mutate(lag=factor(c('Lag 1','Lag 2','Lag 7','Lag 14'),levels=c('Lag 1','Lag 2','Lag 7','Lag 14'))[lag])
daily_true_cor <- tibble(cor=c(cor(r_daily_obs[1:(length(r_daily_obs)-1)],r_daily_obs[2:length(r_daily_obs)],method='spearman'),
                               cor(r_daily_obs[1:(length(r_daily_obs)-2)],r_daily_obs[3:length(r_daily_obs)],method='spearman'),
                               cor(r_daily_obs[1:(length(r_daily_obs)-7)],r_daily_obs[8:length(r_daily_obs)],method='spearman'),
                               cor(r_daily_obs[1:(length(r_daily_obs)-14)],r_daily_obs[15:length(r_daily_obs)],method='spearman')),
                         lag=c(1,2,3,4))%>%
  mutate(lag=factor(c('Lag 1','Lag 2','Lag 7','Lag 14'),levels=c('Lag 1','Lag 2','Lag 7','Lag 14'))[lag])

daily_autocor_plot <- ggplot(daily_cor_data)+
  stat_density(aes(x=cor),alpha=0.5,adjust=1.5,fill=vp[4])+
  labs(y='Density',title='Spearman Auto-Correlation (Daily)',x=NULL)+
  facet_wrap(~lag,scales='free',nrow=1)+
  geom_vline(data=daily_true_cor,aes(xintercept=cor),col="#22211d")+
  theme(text = element_text(color = "#22211d"),plot.background = element_rect(fill = "#f5f5f2", color = NA),
        panel.background = element_rect(fill = "#f5f5f2", color = NA),strip.text = element_text(hjust=0.01,color = "#22211d",size = 12),
        strip.background = element_blank(),panel.grid.minor = element_blank(),plot.title = element_text(hjust=0.01,color = "#22211d",size = 14))+
  scale_fill_viridis_d(begin=0.12,end=0.48,guide='none')
ggsave(daily_autocor_plot,file='Plots/daily_autocor_plot.pdf',width=9,height=2.5)


# Monthly model checking

NM <- N/720
r_monthly <- numeric(NM)
for(t in 1:NM){
  r_monthly[t] <- sum(r[(t-1)*720+1:720])
}

monthly_sim_list <- lapply(rain_sim_list,function(x){
  y <- numeric(NM)
  for(t in 1:NM){
    y[t] <- sum(x[(t-1)*720+1:720])
  }
  return(y)
})

r_monthly_obs <- r_monthly[!is.na(r_monthly)]

monthly_quantiles = do.call("rbind", lapply(monthly_sim_list,function(x){quantile(x[!is.na(r_monthly)],quantiles[seq(1,1001,length=21)])}))

daily_monthly_quantiles <- rbind(data.frame(x=quantile(r_daily_obs[r_daily_obs>0],quantiles[seq(1,1001,length=101)]),l=apply(daily_quantiles,2,quantile,probs=0.025),
                                         u=apply(daily_quantiles,2,quantile,probs=0.975),m=apply(daily_quantiles,2,median),
                                         type='Daily Rainfall'),
                              data.frame(x=quantile(r_monthly_obs,quantiles[seq(1,1001,length=21)]),l=apply(monthly_quantiles,2,quantile,probs=0.025),
                                         u=apply(monthly_quantiles,2,quantile,probs=0.975),m=apply(monthly_quantiles,2,median),
                                         type='Monthly Rainfall'))

# Check daily and monthly rainfall quantiles.
daily_monthly_quantiles_plot <- ggplot(daily_monthly_quantiles)+
  geom_abline(intercept=0,slope=1,col="#22211d")+
  geom_ribbon(aes(x=x,ymin=l,ymax=u,fill=type),alpha=0.5)+
  geom_point(aes(x=x,y=m,colour=type),size=1)+xlab('Observed Quantiles (mm)')+
  facet_wrap(~type,nrow=1,scales='free')+
  ylab('Simulated Quantiles (mm)')+
  theme(text = element_text(color = "#22211d",size=10),plot.background = element_rect(fill = "#f5f5f2", color = NA),
        panel.background = element_rect(fill = "#f5f5f2", color = NA),strip.text = element_text(hjust=0,size = 12),
        strip.background = element_blank(),panel.grid.minor = element_blank())+
  scale_colour_manual(guide=FALSE,values=c(vp[4],vp[6]))+scale_fill_manual(guide=FALSE,values=c(vp[4],vp[6]))

ggsave(daily_monthly_quantiles_plot,file='Plots/daily_monthly_quantiles.pdf',width=6,height=2.25)

# Check monthly auto-correlations.
monthly_cor_1 = do.call("c", lapply(monthly_sim_list,function(x){
  x <- x[!is.na(r_monthly)]
  cor(x[1:(length(x)-1)],x[2:length(x)],method='spearman')
}))
monthly_cor_2 = do.call("c", lapply(monthly_sim_list,function(x){
  x <- x[!is.na(r_monthly)]
  cor(x[1:(length(x)-2)],x[3:length(x)],method='spearman')
}))
monthly_cor_6 = do.call("c", lapply(monthly_sim_list,function(x){
  x <- x[!is.na(r_monthly)]
  cor(x[1:(length(x)-6)],x[7:length(x)],method='spearman')
}))
monthly_cor_12 = do.call("c", lapply(monthly_sim_list,function(x){
  x <- x[!is.na(r_monthly)]
  cor(x[1:(length(x)-12)],x[13:length(x)],method='spearman')
}))

r_monthly_obs <- r_monthly[!is.na(r_monthly)]

monthly_cor_data <- tibble(cor=c(monthly_cor_1,monthly_cor_2,monthly_cor_6,monthly_cor_12),lag=sort(rep(c(1,2,3,4),n_sim)))%>%
  mutate(lag=factor(c('Lag 1','Lag 2','Lag 6','Lag 12'),levels=c('Lag 1','Lag 2','Lag 6','Lag 12'))[lag])
monthly_true_cor <- tibble(cor=c(cor(r_monthly_obs[1:(length(r_monthly_obs)-1)],r_monthly_obs[2:length(r_monthly_obs)],method='spearman'),
                                 cor(r_monthly_obs[1:(length(r_monthly_obs)-2)],r_monthly_obs[3:length(r_monthly_obs)],method='spearman'),
                                 cor(r_monthly_obs[1:(length(r_monthly_obs)-6)],r_monthly_obs[7:length(r_monthly_obs)],method='spearman'),
                                 cor(r_monthly_obs[1:(length(r_monthly_obs)-12)],r_monthly_obs[13:length(r_monthly_obs)],method='spearman')),
                           lag=c(1,2,3,4))%>%
  mutate(lag=factor(c('Lag 1','Lag 2','Lag 6','Lag 12'),levels=c('Lag 1','Lag 2','Lag 6','Lag 12'))[lag])

monthly_autocor_plot <- ggplot(monthly_cor_data)+
  stat_density(aes(x=cor),alpha=0.5,adjust=1.5,fill=vp[5])+
  labs(y='Density',title='Spearman Auto-Correlation (Monthly)',x=NULL)+
  facet_wrap(~lag,scales='free',nrow=1)+
  geom_vline(data=monthly_true_cor,aes(xintercept=cor),col="#22211d")+
  theme(text = element_text(color = "#22211d"),plot.background = element_rect(fill = "#f5f5f2", color = NA),
        panel.background = element_rect(fill = "#f5f5f2", color = NA),strip.text = element_text(hjust=0.01,color = "#22211d",size = 12),
        strip.background = element_blank(),panel.grid.minor = element_blank(),plot.title = element_text(hjust=0.01,color = "#22211d",size = 14))+
  scale_fill_viridis_d(begin=0.12,end=0.48,guide='none')
ggsave(monthly_autocor_plot,file='Plots/monthly_autocor_plot.pdf',width=9,height=2.5)

# Check joint exceedance probabilities (takes a while).

# Function to calculate joint exceedance probability.
joint_prob <- function(x,e,k){
  l=length(x)
  x[is.na(r)] <- NA
  return(mean(x[1:(l-k)]>e&x[(1+k):l]>e,na.rm=T))
}

# Sequence of temporal lags.
k_list=1:12
# Sequence of exceedance thresholds.
r_list=seq(0,5.2,by=0.2)

rain_sims <- do.call('rbind',rain_sim_list)

joint_probs=array(dim=c(n_sim,length(r_list),length(k_list))) 

for(i in 1:length(r_list)){
  for(j in 1:length(k_list)){
    joint_probs[,i,j]=apply(rain_sims,1,function(x)joint_prob(x,r_list[i],k_list[j]))
  }
}

joint_prob_data <- melt(joint_probs,varnames=c('sample','r','k'))%>%mutate(k=k_list[k],r=r_list[r])

# Empirical exceedance probabilities.
data_joint_probs <- matrix(NA,length(r_list),length(k_list))
for(i in 1:length(r_list)){
  for(j in 1:length(k_list)){
    data_joint_probs[i,j]=joint_prob(r,r_list[i],k_list[j])
  }
}
data_joint_prob <- melt(data_joint_probs,varnames=c('r','k'))%>%mutate(k=k_list[k],r=r_list[r])

joint_prob_p <- matrix(NA,length(r_list),length(k_list))
for(i in 1:length(r_list)){
  for(j in 1:length(k_list)){
    joint_prob_p[i,j]=mean(joint_probs[,i,j]<=data_joint_probs[i,j])
  }
}
joint_prob_p_data <- melt(joint_prob_p,varnames=c('r','k'))%>%mutate(k=k_list[k],r=r_list[r],p=ifelse(value<=0.5,value,1-value))

# Plot the exceedance probabilities and contours.
joint_prob_plot <- ggplot(joint_prob_p_data,aes(x=k,y=r,fill=p,z=p,colour=p))+geom_raster(interpolate=T,alpha=0.5)+
  geom_contour(aes(colour=stat(level)),breaks=0.025,size=0.5,linetype=1)+
  geom_contour(aes(colour=stat(level)),breaks=0.05,size=0.5,linetype=2)+
  geom_contour(aes(colour=stat(level)),breaks=0.1,size=0.5,linetype=3)+
  labs(title='Joint Exceedance Probabilities',x='Lag (Hours)',y='Exceedance Level (mm)')+
  theme(text = element_text(color = "#22211d",size=10),plot.background = element_rect(fill = "#f5f5f2", color = NA),
        panel.background = element_rect(fill = "#f5f5f2", color = NA),strip.text = element_text(hjust=0.01,color = "#22211d",size = 10),
        strip.background = element_blank(),plot.title = element_text(hjust=0.01,color = "#22211d",size = 12),
        legend.background = element_blank())+scale_x_continuous(breaks=seq(0,12,by=2))+
  scale_fill_viridis(trans='sqrt',name='Posterior\nTail\nProbability',begin=0.12,end=0.48,breaks=seq(0,0.4,by=0.1),guide=guide_legend())+
  scale_colour_viridis(trans='sqrt',name='Posterior\nTail\nProbability',begin=0.12,end=0.48,breaks=seq(0,0.4,by=0.1),guide=guide_legend())

ggsave(joint_prob_plot,filename = 'Plots/joint_prob.pdf',width=4,height=2.5)


# Exceedence probabilities of simulated rainfall.
breaks=seq(0.2,10,by=0.2)
intensity_toy <- melt(rain_sims,varnames = c('sample','t'))%>%
  mutate(tp=rain_df$tp[t],bin=c(sort(rep(1:52,168)),rep(52,30))[tp])%>%group_by(bin)%>%
  group_modify(function(x,y){
    exc <- sapply(breaks,function(l)mean(x$value[x$value>0]>l))
    return(tibble(l=breaks,p=exc))
  })

# Proportion of non-zero rainfall values.
occurrence_toy <- melt(rain_sims,varnames = c('sample','t'))%>%
  mutate(tp=rain_df$tp[t],bin=c(sort(rep(1:52,168)),rep(52,30))[tp])%>%group_by(bin)%>%
  group_modify(function(x,y){
    occ <- mean(x$value>0)
    return(tibble(p=occ))
  })

intensity_tod <- melt(rain_sims,varnames = c('sample','t'))%>%
  mutate(h=rain_df$h[t])%>%group_by(h)%>%
  group_modify(function(x,y){
    exc <- sapply(breaks,function(l)mean(x$value[x$value>0]>l))
    return(tibble(l=breaks,p=exc))
  })

occurrence_tod <- melt(rain_sims,varnames = c('sample','t'))%>%
  mutate(h=rain_df$h[t])%>%group_by(h)%>%
  group_modify(function(x,y){
    occ <- mean(x$value>0)
    return(tibble(p=occ))
  })

# By time of day.
tod <- ggplot(intensity_tod)+
  geom_contour(aes(x=h,y=l,z=p,colour=..level..),size=1,breaks=seq(0.05,0.5,by=0.15))+
  geom_line(data=occurrence_tod,aes(x=h,y=20*p),size=1,linetype=2)+
  labs(x=NULL,y='Intensity (mm)',title='Hourly Rainfall - Exeter International Airport')+
  theme(text = element_text(color = "#22211d",size=10),plot.background = element_rect(fill = "#f5f5f2", color = NA),
        panel.background = element_rect(fill = "#f5f5f2", color = NA),strip.text = element_text(hjust=0.01,color = "#f5f5f2",size = 10),
        strip.background = element_blank(),plot.title = element_text(hjust=0.01,color = "#22211d",size = 12),
        legend.background = element_blank())+
  scale_colour_viridis(name='Exceedance\n Probability',begin=0.12,end=0.48,breaks=seq(0.05,0.5,by=0.15),guide=guide_legend())+
  scale_x_continuous(breaks=seq(0,24,by=6),
                     labels=c('00:00','06:00','12:00','18:00','24:00'))+
  scale_y_continuous(limits=c(0,5),sec.axis = sec_axis(~./20,name='Probability of Rainfall'))

ggsave(tod,filename='Plots/time_of_day.pdf',width=6,height=2)

# By time of year.
toy <- ggplot(intensity_toy)+
  geom_contour(aes(x=(bin-1)*168+84,y=l,z=p,colour=..level..),size=1,breaks=seq(0.05,0.5,by=0.15))+
  geom_line(data=occurrence_toy,aes(x=(bin-1)*168+84,y=20*p),size=1,linetype=2)+
  labs(x=NULL,y='Intensity (mm)',title='Hourly Rainfall - Exeter International Airport')+
  theme(text = element_text(color = "#22211d",size=10),plot.background = element_rect(fill = "#f5f5f2", color = NA),
        panel.background = element_rect(fill = "#f5f5f2", color = NA),strip.text = element_text(hjust=0.01,color = "#f5f5f2",size = 10),
        strip.background = element_blank(),plot.title = element_text(hjust=0.01,color = "#22211d",size = 12),
        legend.background = element_blank())+
  scale_colour_viridis(name='Exceedance\n Probability',begin=0.12,end=0.6,breaks=seq(0.05,0.5,by=0.15),guide=guide_legend())+
  coord_cartesian(ylim=c(0,4))+
  scale_x_continuous(breaks=c(365.25+(0:5)*2*730.5),
                     labels=c('Jan','Mar','May','Jul','Sep','Nov'))+
  scale_y_continuous(sec.axis = sec_axis(~./20,name='Probability of Rainfall'))

ggsave(toy,filename='Plots/time_of_year.pdf',width=6,height=2)
